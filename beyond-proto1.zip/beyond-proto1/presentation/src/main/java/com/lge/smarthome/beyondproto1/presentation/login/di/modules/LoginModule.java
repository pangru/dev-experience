package com.lge.smarthome.beyondproto1.presentation.login.di.modules;

import com.lge.smarthome.beyondproto1.domain.data.SessionRepository;
import com.lge.smarthome.beyondproto1.domain.data.UserRepository;
import com.lge.smarthome.beyondproto1.domain.login.UserHandler;
import com.lge.smarthome.beyondproto1.domain.login.UuidProvider;
import com.lge.smarthome.beyondproto1.ext_core.login.LimeUserHandler;
import com.lge.smarthome.beyondproto1.ext_core.login.SessionRepositoryImpl;
import com.lge.smarthome.beyondproto1.ext_core.login.UserRepositoryImpl;
import com.lge.smarthome.beyondproto1.ext_core.login.UuidProviderImpl;

import dagger.Module;
import dagger.Provides;

@Module
public class LoginModule {
    @Provides
    UuidProvider provideUuidProvider() {
        return new UuidProviderImpl();
    }

    @Provides
    UserHandler provideUserHandler() {
        return new LimeUserHandler();
    }

    @Provides
    UserRepository provideUserRepository() {
        return new UserRepositoryImpl();
    }

    @Provides
    SessionRepository provideSessionRepository() {
        return new SessionRepositoryImpl();
    }
}
