package com.lge.smarthome.beyondproto1.presentation.login;

import com.lge.smarthome.beyondproto1.domain.UseCase;
import com.lge.smarthome.beyondproto1.domain.User;
import com.lge.smarthome.beyondproto1.domain.login.LoginUseCase;
import com.lge.smarthome.beyondproto1.presentation.Presenter;

import javax.inject.Inject;

import rx.Subscriber;

public class LoginPresenter implements Presenter {

    private final UseCase loginUseCase;

    @Inject
    public LoginPresenter(LoginUseCase loginUseCase) {
        this.loginUseCase = loginUseCase;
    }

    @Override
    public void resume() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void destroy() {

    }

    public void login() {
        loginUseCase.execute(new LoginSubscriber());

    }

    private final class LoginSubscriber extends Subscriber<User> {

        @Override
        public void onCompleted() {

        }

        @Override
        public void onError(Throwable e) {

        }

        @Override
        public void onNext(User user) {

        }
    }
}
