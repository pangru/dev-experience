package com.lge.smarthome.beyondproto1.presentation.login.di.components;

import com.lge.smarthome.beyondproto1.presentation.MainActivity;
import com.lge.smarthome.beyondproto1.presentation.login.di.PerActivity;
import com.lge.smarthome.beyondproto1.presentation.login.di.modules.ApplicationModule;
import com.lge.smarthome.beyondproto1.presentation.login.di.modules.LoginModule;

import javax.inject.Singleton;

import dagger.Component;

@PerActivity
@Component(dependencies = ApplicationComponent.class, modules = {LoginModule.class})
public interface LoginComponent {
    void inject(MainActivity activity);
}
