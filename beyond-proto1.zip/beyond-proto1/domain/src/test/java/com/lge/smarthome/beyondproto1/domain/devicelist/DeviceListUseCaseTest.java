package com.lge.smarthome.beyondproto1.domain.devicelist;

import com.lge.smarthome.beyondproto1.domain.PostExecutionThread;
import com.lge.smarthome.beyondproto1.domain.ThreadExecutor;
import com.lge.smarthome.beyondproto1.domain.User;
import com.lge.smarthome.beyondproto1.domain.data.DeviceRepository;
import com.lge.smarthome.beyondproto1.domain.data.SessionRepository;
import com.lge.smarthome.beyondproto1.domain.data.UserRepository;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import rx.Observable;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.anyVararg;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class DeviceListUseCaseTest {
    private DeviceListUseCase usecase;

    @Mock ThreadExecutor mockThreadExecutor;
    @Mock PostExecutionThread mockPostExecutionThread;
    @Mock SessionRepository mockSessionRepository;
    @Mock UserRepository mockUserRepository;
    @Mock DeviceRepository mockDeviceRepository;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        usecase = new DeviceListUseCase(mockThreadExecutor, mockPostExecutionThread, mockSessionRepository, mockUserRepository, mockDeviceRepository);
    }

    @Test
    public void testBuildUseCaseObservable() throws Exception {
        usecase.buildUseCaseObservable();

        verify(mockSessionRepository).get(anyString());
        verifyNoMoreInteractions(mockUserRepository, mockSessionRepository);
        verifyZeroInteractions(mockThreadExecutor);
        verifyZeroInteractions(mockPostExecutionThread);
    }
}