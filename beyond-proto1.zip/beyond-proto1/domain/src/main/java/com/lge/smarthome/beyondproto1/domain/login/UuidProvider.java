package com.lge.smarthome.beyondproto1.domain.login;


public interface UuidProvider {
    String getUuid();
    String getToken();
}
