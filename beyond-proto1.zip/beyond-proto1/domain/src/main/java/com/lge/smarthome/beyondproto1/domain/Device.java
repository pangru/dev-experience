package com.lge.smarthome.beyondproto1.domain;

/**
 * Created by khj8706 on 9/8/16.
 */
public class Device {
}
