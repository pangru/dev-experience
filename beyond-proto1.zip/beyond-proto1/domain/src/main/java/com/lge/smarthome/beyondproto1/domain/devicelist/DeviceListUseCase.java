package com.lge.smarthome.beyondproto1.domain.devicelist;

import com.lge.smarthome.beyondproto1.domain.Device;
import com.lge.smarthome.beyondproto1.domain.PostExecutionThread;
import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.domain.ThreadExecutor;
import com.lge.smarthome.beyondproto1.domain.UseCase;
import com.lge.smarthome.beyondproto1.domain.User;
import com.lge.smarthome.beyondproto1.domain.data.DeviceRepository;
import com.lge.smarthome.beyondproto1.domain.data.SessionRepository;
import com.lge.smarthome.beyondproto1.domain.data.UserRepository;

import java.util.List;

import javax.inject.Inject;

import rx.Observable;
import rx.functions.Func1;


public class DeviceListUseCase extends UseCase {
    SessionRepository sessionRepository;
    UserRepository userRepository;
    DeviceRepository deviceRepository;

    @Inject
    protected DeviceListUseCase(ThreadExecutor threadExecutor, PostExecutionThread postExecutionThread,
                                 SessionRepository sessionRepository,
                                 UserRepository userRepository, DeviceRepository deviceRepository) {
        super(threadExecutor, postExecutionThread);
        this.sessionRepository = sessionRepository;
        this.userRepository = userRepository;
        this.deviceRepository = deviceRepository;
    }

    @Override
    protected Observable buildUseCaseObservable() {
        return userRepository.get()
                .switchMap(new Func1<User, Observable<Session>>() {
                    @Override
                    public Observable<Session> call(User user) {
                        return sessionRepository.get(user.getId());
                    }
                }).switchMap(new Func1<Session, Observable<List<Device>>>() {
                    @Override
                    public Observable<List<Device>> call(Session session) {
                        return deviceRepository.getDeviceList(session);
                    }
                });
    }
}
