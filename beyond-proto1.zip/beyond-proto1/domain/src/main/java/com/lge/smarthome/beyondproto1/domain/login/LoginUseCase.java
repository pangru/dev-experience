package com.lge.smarthome.beyondproto1.domain.login;

import com.lge.smarthome.beyondproto1.domain.PostExecutionThread;
import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.domain.ThreadExecutor;
import com.lge.smarthome.beyondproto1.domain.Tupple2;
import com.lge.smarthome.beyondproto1.domain.UseCase;
import com.lge.smarthome.beyondproto1.domain.User;
import com.lge.smarthome.beyondproto1.domain.data.SessionRepository;
import com.lge.smarthome.beyondproto1.domain.data.UserRepository;

import javax.inject.Inject;

import rx.Observable;
import rx.functions.Func1;


public class LoginUseCase extends UseCase {
    private final static String ACCOUNT_TYPE = "uuid";

    private final UuidProvider uuidProvider;
    private final UserHandler userHandler;
    private final UserRepository userRepository;
    private final SessionRepository sessionRepository;

    @Inject
    protected LoginUseCase(ThreadExecutor threadExecutor, PostExecutionThread postExecutionThread,
                           UuidProvider uuidProvider, UserHandler userHandler,
                           UserRepository userRepository, SessionRepository sessionRepository) {
        super(threadExecutor, postExecutionThread);
        this.uuidProvider = uuidProvider;
        this.userHandler = userHandler;
        this.userRepository = userRepository;
        this.sessionRepository = sessionRepository;
    }

    @Override
    protected Observable buildUseCaseObservable() {
        return userHandler.registerUser(ACCOUNT_TYPE, uuidProvider.getToken())
            .map(new Func1<Tupple2<Session, User>, User>() {
                @Override
                public User call(Tupple2<Session, User> response) {
                    sessionRepository.set(response.getObj1());
                    User user = response.getObj2();
                    userRepository.set(user);
                    return user;
                }
            });
    }
}
