package com.lge.smarthome.beyondproto1.domain.data;


import com.lge.smarthome.beyondproto1.domain.Session;

import rx.Observable;

public interface SessionRepository {
    void set(Session session);
    Observable<Session> get(String id);
    Observable<Session> get();
}
