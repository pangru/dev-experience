package com.lge.smarthome.beyondproto1.domain;

/**
 * Created by wonil.hwang on 9/7/16.
 */
public class Session {
    private String id;
    private String key;

    public Session(String sessionId, String sessoinKey) {
        this.id = sessionId;
        this.key = sessoinKey;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getId() {

        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
