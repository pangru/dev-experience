package com.lge.smarthome.beyondproto1.domain.data;


import com.lge.smarthome.beyondproto1.domain.User;

import rx.Observable;

public interface UserRepository {
    void set(User user);
    Observable<User> get();
}
