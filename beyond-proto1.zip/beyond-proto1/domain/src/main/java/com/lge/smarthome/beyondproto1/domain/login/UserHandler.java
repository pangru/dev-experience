package com.lge.smarthome.beyondproto1.domain.login;

import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.domain.Tupple2;
import com.lge.smarthome.beyondproto1.domain.User;

import rx.Observable;

public interface UserHandler {
    Observable<Tupple2<Session, User>> registerUser(String type, String token);
}
