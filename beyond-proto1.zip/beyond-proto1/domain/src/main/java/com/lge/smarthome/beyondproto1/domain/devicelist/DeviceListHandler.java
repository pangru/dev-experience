package com.lge.smarthome.beyondproto1.domain.devicelist;

import com.lge.smarthome.beyondproto1.domain.Device;
import com.lge.smarthome.beyondproto1.domain.Session;

import java.util.List;
import rx.Observable;


public interface DeviceListHandler {
    Observable<List<Device>> getDeviceList(Session userSession);

}
