package com.lge.smarthome.beyondproto1.domain.data;


import com.lge.smarthome.beyondproto1.domain.Device;
import com.lge.smarthome.beyondproto1.domain.Session;

import java.util.List;

import rx.Observable;

public interface DeviceRepository {
    Observable<List<Device>> getDeviceList(Session userSession);
}
