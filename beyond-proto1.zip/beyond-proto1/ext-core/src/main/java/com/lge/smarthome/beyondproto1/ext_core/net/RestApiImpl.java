package com.lge.smarthome.beyondproto1.ext_core.net;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.ext_core.entity.DeviceEntity;
import com.lge.smarthome.beyondproto1.ext_core.entity.mapper.DeviceEntityJsonMapper;
import com.lge.smarthome.beyondproto1.ext_core.exception.NetworkConnectionException;

import java.net.MalformedURLException;
import java.util.List;

import rx.Observable;

public class RestApiImpl implements RestApi {

    private final Context context;
    private final DeviceEntityJsonMapper deviceEntityJsonMapper;

    public RestApiImpl(Context context, DeviceEntityJsonMapper userEntityJsonMapper) {
        if (context == null || userEntityJsonMapper == null) {
            throw new IllegalArgumentException("The constructor parameters cannot be null!!!");
        }
        this.context = context.getApplicationContext();
        this.deviceEntityJsonMapper = userEntityJsonMapper;
    }


    @Override
    public Observable<List<DeviceEntity>> deviceEntityList(Session userSession) {
        return null;
    }


    private String getDeviceEntitiesFromApi() throws MalformedURLException {
        return ApiConnection.createGET(API_URL_GET_DEVICE_LIST).requestSyncCall();
    }


    /**
     * Checks if the device has any active internet connection.
     *
     * @return true device with internet connection, otherwise false.
     */
    private boolean isThereInternetConnection() {
        boolean isConnected;

        ConnectivityManager connectivityManager =
            (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        isConnected = (networkInfo != null && networkInfo.isConnectedOrConnecting());

        return isConnected;
    }
}
