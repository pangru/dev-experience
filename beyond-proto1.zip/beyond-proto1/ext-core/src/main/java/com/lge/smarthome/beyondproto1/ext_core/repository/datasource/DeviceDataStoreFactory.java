package com.lge.smarthome.beyondproto1.ext_core.repository.datasource;

import android.content.Context;
import android.support.annotation.NonNull;
import com.lge.smarthome.beyondproto1.ext_core.cache.DeviceCache;
import com.lge.smarthome.beyondproto1.ext_core.entity.mapper.DeviceEntityJsonMapper;
import com.lge.smarthome.beyondproto1.ext_core.net.RestApi;
import com.lge.smarthome.beyondproto1.ext_core.net.RestApiImpl;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Factory that creates different implementations of {@link DeviceDataStore}.
 */
@Singleton
public class DeviceDataStoreFactory {

  private final Context context;
  private final DeviceCache deviceCache;

  @Inject
  public DeviceDataStoreFactory(@NonNull Context context, @NonNull DeviceCache deviceCache) {
    this.context = context.getApplicationContext();
    this.deviceCache = deviceCache;
  }


  public DeviceDataStore create(int userId) {
    DeviceDataStore userDataStore;

//    if (!this.deviceCache.isExpired() && this.deviceCache.isCached(userId)) {
//      userDataStore = new DiskDeviceDataStore(this.deviceCache);
//    } else {
      userDataStore = createCloudDataStore();
//    }

    return userDataStore;
  }

  /**
   * Create {@link DeviceDataStore} to retrieve data from the Cloud.
   */
  public DeviceDataStore createCloudDataStore() {
    DeviceEntityJsonMapper userEntityJsonMapper = new DeviceEntityJsonMapper();
    RestApi restApi = new RestApiImpl(this.context, userEntityJsonMapper);

    return new CloudDeviceDataStore(restApi, this.deviceCache);
  }
}
