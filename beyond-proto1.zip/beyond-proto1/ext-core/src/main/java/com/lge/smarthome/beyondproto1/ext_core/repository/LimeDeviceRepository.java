package com.lge.smarthome.beyondproto1.ext_core.repository;

import com.lge.smarthome.beyondproto1.domain.Device;
import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.domain.data.DeviceRepository;
import com.lge.smarthome.beyondproto1.ext_core.entity.DeviceEntity;
import com.lge.smarthome.beyondproto1.ext_core.entity.mapper.DeviceEntityDataMapper;
import com.lge.smarthome.beyondproto1.ext_core.repository.datasource.DeviceDataStore;
import com.lge.smarthome.beyondproto1.ext_core.repository.datasource.DeviceDataStoreFactory;

import java.util.List;

import javax.inject.Inject;

import rx.Observable;
import rx.functions.Func1;

public class LimeDeviceRepository implements DeviceRepository{
    DeviceEntityDataMapper deviceEntityDataMapper;
    DeviceDataStoreFactory deviceDataStoreFactory;

    @Inject
    public LimeDeviceRepository(DeviceEntityDataMapper deviceEntityDataMapper, DeviceDataStoreFactory deviceDataStoreFactory) {
        this.deviceEntityDataMapper = deviceEntityDataMapper;
        this.deviceDataStoreFactory = deviceDataStoreFactory;
    }

    @Override
    public Observable<List<Device>> getDeviceList(Session userSession) {
        final DeviceDataStore deviceDataStore = this.deviceDataStoreFactory.createCloudDataStore();
        return deviceDataStore.deviceEntityList(userSession).map(new Func1<List<DeviceEntity>, List<Device>>() {
            @Override
            public List<Device> call(List<DeviceEntity> deviceEntities) {
                return deviceEntityDataMapper.transform(deviceEntities);
            }
        });
    }
}
