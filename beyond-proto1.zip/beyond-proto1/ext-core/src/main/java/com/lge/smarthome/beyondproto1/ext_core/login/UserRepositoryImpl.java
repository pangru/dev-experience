package com.lge.smarthome.beyondproto1.ext_core.login;

import com.lge.smarthome.beyondproto1.domain.User;
import com.lge.smarthome.beyondproto1.domain.data.UserRepository;

import javax.inject.Inject;

import rx.Observable;

/**
 * Created by osung on 2016. 9. 8..
 */

public class UserRepositoryImpl implements UserRepository {

    @Inject
    public UserRepositoryImpl() {
    }

    @Override
    public void set(User user) {

    }

    @Override
    public Observable<User> get() {
        return null;
    }
}
