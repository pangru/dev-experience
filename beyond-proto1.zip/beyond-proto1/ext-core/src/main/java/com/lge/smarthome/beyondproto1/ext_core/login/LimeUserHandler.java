package com.lge.smarthome.beyondproto1.ext_core.login;

import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.domain.Tupple2;
import com.lge.smarthome.beyondproto1.domain.User;
import com.lge.smarthome.beyondproto1.domain.login.UserHandler;

import javax.inject.Inject;

import rx.Observable;

public class LimeUserHandler implements UserHandler{

    @Inject
    public LimeUserHandler() {
    }

    @Override
    public Observable<Tupple2<Session, User>> registerUser(String type, String token) {
        return null;
    }
}
