package com.lge.smarthome.beyondproto1.ext_core.entity;


public class DeviceEntity {
}
