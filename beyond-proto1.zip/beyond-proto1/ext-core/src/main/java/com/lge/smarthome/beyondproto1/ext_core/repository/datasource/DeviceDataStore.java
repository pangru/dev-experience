package com.lge.smarthome.beyondproto1.ext_core.repository.datasource;

import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.ext_core.entity.DeviceEntity;

import java.util.List;
import rx.Observable;
public interface DeviceDataStore {

  Observable<List<DeviceEntity>> deviceEntityList(Session userSession);

}
