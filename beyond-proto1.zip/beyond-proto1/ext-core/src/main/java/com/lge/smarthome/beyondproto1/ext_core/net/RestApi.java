package com.lge.smarthome.beyondproto1.ext_core.net;

import com.lge.smarthome.beyondproto1.domain.Device;
import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.ext_core.entity.DeviceEntity;

import java.util.List;
import rx.Observable;

public interface RestApi {
  String API_BASE_URL = "https://api-qa.lglime.com/v1";
  public static final String SERVICE_ID = "ce2aeaf403a6f92786fb9a48";

  String API_URL_GET_DEVICE_LIST = API_BASE_URL + "/devices/";

  Observable<List<DeviceEntity>> deviceEntityList(Session userSession);
}
