package com.lge.smarthome.beyondproto1.ext_core.entity.mapper;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.lge.smarthome.beyondproto1.ext_core.entity.DeviceEntity;

import java.lang.reflect.Type;
import java.util.List;
import javax.inject.Inject;

public class DeviceEntityJsonMapper {

  private final Gson gson;

  @Inject
  public DeviceEntityJsonMapper() {
    this.gson = new Gson();
  }

  public DeviceEntity transformDeviceEntity(String userJsonResponse) throws JsonSyntaxException {
    try {
      Type deviceEntityType = new TypeToken<DeviceEntity>() {}.getType();
      DeviceEntity deviceEntity = this.gson.fromJson(userJsonResponse, deviceEntityType);

      return deviceEntity;
    } catch (JsonSyntaxException jsonException) {
      throw jsonException;
    }
  }

  public List<DeviceEntity> transformDeviceEntityCollection(String deviceListJsonResponse)
      throws JsonSyntaxException {

    List<DeviceEntity> deviceEntityCollection;
    try {
      Type listOfDeviceEntityType = new TypeToken<List<DeviceEntity>>() {}.getType();
      deviceEntityCollection = this.gson.fromJson(deviceListJsonResponse, listOfDeviceEntityType);

      return deviceEntityCollection;
    } catch (JsonSyntaxException jsonException) {
      throw jsonException;
    }
  }
}
