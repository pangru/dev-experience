package com.lge.smarthome.beyondproto1.ext_core.cache;

import com.lge.smarthome.beyondproto1.ext_core.entity.DeviceEntity;

import rx.Observable;

/**
 * An interface representing a user Cache.
 */
public interface DeviceCache {
  /**
   * Gets an {@link Observable} which will emit a {@link DeviceEntity}.
   *
   * @param userId The user id to retrieve data.
   */
  Observable<DeviceEntity> get(final int userId);

  /**
   * Puts and element into the cache.
   *
   * @param deviceEntity Element to insert in the cache.
   */
  void put(DeviceEntity deviceEntity);

  boolean isCached();

  /**
   * Checks if the cache is expired.
   *
   * @return true, the cache is expired, otherwise false.
   */
  boolean isExpired();

  /**
   * Evict all elements of the cache.
   */
  void evictAll();
}
