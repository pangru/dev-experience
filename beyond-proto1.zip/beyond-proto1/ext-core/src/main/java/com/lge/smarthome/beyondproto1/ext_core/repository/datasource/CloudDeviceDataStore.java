package com.lge.smarthome.beyondproto1.ext_core.repository.datasource;

import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.ext_core.cache.DeviceCache;
import com.lge.smarthome.beyondproto1.ext_core.entity.DeviceEntity;
import com.lge.smarthome.beyondproto1.ext_core.net.RestApi;

import java.util.List;

import rx.Observable;

class CloudDeviceDataStore implements DeviceDataStore {

    private final RestApi restApi;
    private final DeviceCache deviceCache;

    CloudDeviceDataStore(RestApi restApi, DeviceCache deviceCache) {
        this.restApi = restApi;
        this.deviceCache = deviceCache;
    }

    @Override
    public Observable<List<DeviceEntity>> deviceEntityList(Session userSession) {
        return this.restApi.deviceEntityList(userSession);
    }
}
