package com.lge.smarthome.beyondproto1.ext_core.entity.mapper;

import com.lge.smarthome.beyondproto1.domain.Device;
import com.lge.smarthome.beyondproto1.ext_core.entity.DeviceEntity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class DeviceEntityDataMapper {

  @Inject
  public DeviceEntityDataMapper() {}

  public Device transform(DeviceEntity deviceEntity) {
    Device device = null;
    if (deviceEntity != null) {
      device = new Device();
    }

    return device;
  }

  public List<Device> transform(Collection<DeviceEntity> deviceEntityCollection) {
    List<Device> deviceList = new ArrayList<>();
    Device device;
    for (DeviceEntity deviceEntity : deviceEntityCollection) {
      device = transform(deviceEntity);
      if (device != null) {
        deviceList.add(device);
      }
    }

    return deviceList;
  }
}
