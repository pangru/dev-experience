package com.lge.smarthome.beyondproto1.ext_core.login;

import com.lge.smarthome.beyondproto1.domain.Session;
import com.lge.smarthome.beyondproto1.domain.data.SessionRepository;

import javax.inject.Inject;

import rx.Observable;

/**
 * Created by osung on 2016. 9. 8..
 */

public class SessionRepositoryImpl implements SessionRepository {

    @Inject
    public SessionRepositoryImpl() {
    }

    @Override
    public void set(Session session) {

    }

    @Override
    public Observable<Session> get(String id) {
        return null;
    }

    @Override
    public Observable<Session> get() {
        return null;
    }
}
