package com.lge.smarthome.beyondproto1.ext_core.login;

import com.lge.smarthome.beyondproto1.domain.login.UuidProvider;

import javax.inject.Inject;

/**
 * Created by osung on 2016. 9. 8..
 */

public class UuidProviderImpl implements UuidProvider {

    @Inject
    public UuidProviderImpl() {
    }

    @Override
    public String getUuid() {
        return null;
    }

    @Override
    public String getToken() {
        return null;
    }
}
